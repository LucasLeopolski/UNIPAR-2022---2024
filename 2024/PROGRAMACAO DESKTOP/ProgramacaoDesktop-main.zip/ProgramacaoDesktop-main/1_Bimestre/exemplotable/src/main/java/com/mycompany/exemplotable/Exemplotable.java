/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exemplotable;

/**
 *
 * @author paulodossantos
 */
public class Exemplotable {

    public static void main(String[] args) {
        new PrincipalFrame().setVisible(true);
    }
}
