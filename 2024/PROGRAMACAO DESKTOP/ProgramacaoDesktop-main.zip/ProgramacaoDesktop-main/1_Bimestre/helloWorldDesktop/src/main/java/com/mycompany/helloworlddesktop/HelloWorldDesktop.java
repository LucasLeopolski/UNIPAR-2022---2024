/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.helloworlddesktop;

/**
 *
 * @author paulodossantos
 */
public class HelloWorldDesktop {

    public static void main(String[] args) {
        //new FrameHelloWorld().setVisible(true);
        new FrameCadastro().setVisible(true);
    }
}
