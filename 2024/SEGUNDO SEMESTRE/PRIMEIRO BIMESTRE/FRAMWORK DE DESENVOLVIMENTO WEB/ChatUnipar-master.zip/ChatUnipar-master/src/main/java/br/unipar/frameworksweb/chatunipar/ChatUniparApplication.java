package br.unipar.frameworksweb.chatunipar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatUniparApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChatUniparApplication.class, args);
    }

}
