package br.unipar.frameworksweb.chatunipar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatUniparApplicationTests {

    @Test
    void contextLoads() {
    }

}
